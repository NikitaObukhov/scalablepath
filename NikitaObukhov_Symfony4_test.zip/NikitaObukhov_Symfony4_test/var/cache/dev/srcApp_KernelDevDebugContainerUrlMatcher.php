<?php

use Symfony\Component\Routing\Matcher\Dumper\PhpMatcherTrait;
use Symfony\Component\Routing\RequestContext;

/**
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class srcApp_KernelDevDebugContainerUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    use PhpMatcherTrait;

    public function __construct(RequestContext $context)
    {
        $this->context = $context;
        $this->staticRoutes = [
            '/products' => [[['_route' => 'product', '_controller' => 'App\\Controller\\ProductController::index'], null, ['GET' => 0], null, false, false, null]],
        ];
        $this->regexpList = [
            0 => '{^(?'
                    .'|/products/([^/]++)(*:25)'
                .')/?$}sDu',
        ];
        $this->dynamicRoutes = [
            25 => [[['_route' => 'product_delete', '_controller' => 'App\\Controller\\ProductController::remove'], ['id'], ['DELETE' => 0], null, false, true, null]],
        ];
    }
}
